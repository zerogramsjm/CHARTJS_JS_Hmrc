// // external js: flickity.pkgd.js

// var $carouselMain = $('.carousel-main').flickity();

// var $carouselNav = $('.carousel-nav').flickity({
//   contain: true,
//   pageDots: false,
// });

// $carouselNav.on( 'staticClick.flickity', function(  event, pointer, cellElement, cellIndex ) {
//   if ( cellElement.id == 'GBUKC' ) {
//        // if (this.id === 'GBUKC') {
//  alert('1');
//   }
//   if ( cellElement.id == 'GBUKD' ) {
//        // if (this.id === 'GBUKC') {
//  alert('2');
//   }
//   if ( cellElement.id == 'GBUKE' ) {
//        // if (this.id === 'GBUKC') {
//  alert('3');
//   }
//   if ( cellElement.id == 'GBUKF' ) {
//        // if (this.id === 'GBUKC') {
//  alert('4');
//   }
//   if ( cellElement.id == 'GBUKG' ) {
//        // if (this.id === 'GBUKC') {
//  alert('5');
//   }
//   if ( cellElement.id == 'GBUKH' ) {
//        // if (this.id === 'GBUKC') {
//  alert('6');
//   }
//   if ( cellElement.id == 'GBUKI' ) {
//        // if (this.id === 'GBUKC') {
//  alert('7');
//   }
//   if ( cellElement.id == 'GBUKJ' ) {
//        // if (this.id === 'GBUKC') {
//  alert('8');
//   }
//   if ( cellElement.id == 'GBUKK' ) {
//        // if (this.id === 'GBUKC') {
//  alert('9');
//   }
//   if ( cellElement.id == 'GBUKL' ) {
//        // if (this.id === 'GBUKC') {
//  alert('10');
//   }
//   if ( cellElement.id == 'GBUKM' ) {
//        // if (this.id === 'GBUKC') {
//  alert('11');
//   }
//   if ( cellElement.id == 'GBUKN' ) {
//        // if (this.id === 'GBUKC') {
//  alert('12');
//   }
  
// })


//    if (cellElement.id = 'GBUKC') {
// chart.dataProvider = chartData.GBUKC;
// chart1.dataProvider = chartData.GBUKC;
// document.getElementById( "tab-3-content" ).innerHTML = "£46,414";
// document.getElementById( "info" ).innerHTML = '<p><b>' + 'R&D in North East' + '</b></p><p>' + '</p>';
// document.getElementById( "location" ).innerHTML = 'North East';
// graph1.labelText = "[[label1]]";
// dropdowntest();
//    }
//    if (cellElement.id = 'GBUKD') {
// chart.dataProvider = chartData.GBUKD;
// chart1.dataProvider = chartData.GBUKD;
// document.getElementById( "tab-3-content" ).innerHTML = "£41,612";
// document.getElementById( "info" ).innerHTML = '<p><b>' + 'R&D in North West' + '</b></p><p>' + '</p>';
// document.getElementById( "location" ).innerHTML = 'North West';
// dropdowntest();
//    }
//    if (cellElement.id = 'GBUKE') {
// chart.dataProvider = chartData.GBUKE;
// chart1.dataProvider = chartData.GBUKE;
// document.getElementById( "tab-3-content" ).innerHTML = "£37,363";
// document.getElementById( "info" ).innerHTML = '<p><b>' + 'R&D in Yorkshire & The Humber' + '</b></p><p>' + '</p>';
// document.getElementById( "location" ).innerHTML = 'North West';
// dropdowntest();
//    }
//    if (cellElement.id = 'GBUKF') {
// chart.dataProvider = chartData.GBUKF;
// chart1.dataProvider = chartData.GBUKF;
// document.getElementById( "tab-3-content" ).innerHTML = "£48,077";
// document.getElementById( "info" ).innerHTML = '<p><b>' + 'R&D in East Midlands' + '</b></p><p>' + '</p>';
// document.getElementById( "location" ).innerHTML = 'East Midlands';
// dropdowntest();
//    }
//    if (cellElement.id = 'GBUKG') {
// chart.dataProvider = chartData.GBUKG;
// chart1.dataProvider = chartData.GBUKG;
// document.getElementById( "tab-3-content" ).innerHTML = "£37,866";
// document.getElementById( "info" ).innerHTML = '<p><b>' + 'R&D in West Midlands' + '</b></p><p>' + '</p>';
// document.getElementById( "location" ).innerHTML = 'East Midlands';
// dropdowntest();
//    }
//    if (cellElement.id = 'GBUKH') {
// chart.dataProvider = chartData.GBUKH;
// chart1.dataProvider = chartData.GBUKH;
// document.getElementById( "tab-3-content" ).innerHTML = "£63,348";
// document.getElementById( "info" ).innerHTML = '<p><b>' + 'R&D in  East of England' + '</b></p><p>' + '</p>';
// document.getElementById( "location" ).innerHTML = 'East Midlands';
// dropdowntest();
//    }
//    if (cellElement.id = 'GBUKI') {
// chart.dataProvider = chartData.GBUKI;
// chart1.dataProvider = chartData.GBUKI;
// document.getElementById( "tab-3-content" ).innerHTML = "£74,695";
// document.getElementById( "info" ).innerHTML = '<p><b>' + 'R&D in London' + '</b></p><p>' + '</p>';
// document.getElementById( "location" ).innerHTML = 'East Midlands';
// dropdowntest();
//    }
//    if (cellElement.id = 'GBUKJ') {
// chart.dataProvider = chartData.GBUKJ;
// chart1.dataProvider = chartData.GBUKJ;
// document.getElementById( "tab-3-content" ).innerHTML = "£62,857";
// document.getElementById( "info" ).innerHTML = '<p><b>' + 'R&D in South East' + '</b></p><p>' + '</p>';
// document.getElementById( "location" ).innerHTML = 'East Midlands';
// dropdowntest();
//    }
//    if (cellElement.id = 'GBUKK') {
// chart.dataProvider = chartData.GBUKK;
// chart1.dataProvider = chartData.GBUKK;
// document.getElementById( "tab-3-content" ).innerHTML = "£40,590";
// document.getElementById( "info" ).innerHTML = '<p><b>' + 'R&D in South West' + '</b></p><p>' + '</p>';
// document.getElementById( "location" ).innerHTML = 'East Midlands';
// dropdowntest();
//    }
//    if (cellElement.id = 'GBUKL') {
// chart.dataProvider = chartData.GBUKL;
// chart1.dataProvider = chartData.GBUKL;
// document.getElementById( "tab-3-content" ).innerHTML = "£46,590";
// document.getElementById( "info" ).innerHTML = '<p><b>' + 'R&D in Wales' + '</b></p><p>' + '</p>';
// document.getElementById( "location" ).innerHTML = 'East Midlands';
// dropdowntest();
//    }
//    if (cellElement.id = 'GBUKM') {
// chart.dataProvider = chartData.GBUKM;
// chart1.dataProvider = chartData.GBUKM;
// document.getElementById( "tab-3-content" ).innerHTML = "£52,632";
// document.getElementById( "info" ).innerHTML = '<p><b>' + 'R&D in East Midlands' + '</b></p><p>' + '</p>';
// document.getElementById( "location" ).innerHTML = 'Scotland';
// dropdowntest();
//    }
//    if (cellElement.id = 'GBUKN') {
// chart.dataProvider = chartData.GBUKN;
// chart1.dataProvider = chartData.GBUKN;
// document.getElementById( "tab-3-content" ).innerHTML = "£40,201";
// document.getElementById( "info" ).innerHTML = '<p><b>' + 'R&D in Northern Ireland' + '</b></p><p>' + '</p>';
// document.getElementById( "location" ).innerHTML = 'East Midlands';
// dropdowntest();
//    }

// });